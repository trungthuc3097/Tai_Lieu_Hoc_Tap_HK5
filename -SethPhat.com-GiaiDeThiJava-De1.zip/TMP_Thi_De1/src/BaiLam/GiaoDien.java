package BaiLam;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.BorderLayout;

public class GiaoDien extends JFrame implements ActionListener {
	// Component cần thiết
	JTextField txtMaSach, txtTenSach, txtNam;
	JButton btnBack, btnNext, btnSapXep, btnAdd, btnCancel, btnDel, btnClose;
	JLabel lblInfo;
	
	// Kết nối CSDL
	private QuanLySach qly = new QuanLySach();
	private ArrayList<Sach> data = qly.getAllSach(); // Mặc định lấy toàn bộ sách khi chạy
	private int nowPlace = 0; // vị trí mặc định hiện tại
	
	// Constructor
	public GiaoDien() {
		setTitle("Quản lý sách - Trần Minh Phát - SethPhat.com");
		getContentPane().setLayout(null);
		
		// === Create components
		// Tieu de
		JLabel lblTieuDe = new JLabel("Quản Lý Sách");
		lblTieuDe.setHorizontalAlignment(SwingConstants.CENTER);
		lblTieuDe.setBounds(10, 11, 494, 30);
		lblTieuDe.setFont(new Font("Arial", Font.BOLD, 16));
		
		// JPanel to contain
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		//panel.setBackground(Color.WHITE);
		panel.setBounds(5, 50, 400, 194);
		
		// Panel thứ 2 - chứa textbox 
		JPanel panelTop = new JPanel();
		panelTop.setBounds(1, 1, 398, 134);
		panelTop.setBackground(Color.LIGHT_GRAY);
		panelTop.setLayout(null);
		
		// Ma sach
		JLabel lblMaSach = new JLabel("Mã Sách");
		lblMaSach.setBounds(10, 11, 64, 14);
		panelTop.add(lblMaSach);
		
		txtMaSach = new JTextField();
		txtMaSach.setBounds(105, 8, 283, 20);
		panelTop.add(txtMaSach);
		
		// Ten sach
		JLabel lblTenSach = new JLabel("Tên Sách");
		lblTenSach.setBounds(10, 52, 80, 14);
		panelTop.add(lblTenSach);
		
		txtTenSach = new JTextField();
		txtTenSach.setBounds(105, 49, 283, 20);
		panelTop.add(txtTenSach);
		
		// Nam san xuat
		JLabel lblNam = new JLabel("Năm sản xuất");
		lblNam.setBounds(10, 96, 100, 14);
		panelTop.add(lblNam);
		
		txtNam = new JTextField();
		txtNam.setBounds(105, 93, 283, 20);
		panelTop.add(txtNam);
		
		// Add components to form
		getContentPane().add(lblTieuDe);
		getContentPane().add(panel);
		panel.setLayout(null);
		panel.add(panelTop);
		
		JPanel panelBottom = new JPanel();
		panelBottom.setBounds(1, 135, 398, 50);
		panel.add(panelBottom);
		panelBottom.setLayout(null);
		
		// Nut back
		btnBack = new JButton("<<");
		panelBottom.add(btnBack);
		btnBack.setBounds(94, 11, 66, 35);
		btnBack.addActionListener(this);
		
		// Nut next
		btnNext = new JButton(">>");
		panelBottom.add(btnNext);
		btnNext.setBounds(241, 11, 66, 35);
		btnNext.addActionListener(this);
		
		// Info
		lblInfo = new JLabel("1/" + data.size()); // vì đã get dc data, show luôn toàn bộ giá trị
		lblInfo.setHorizontalAlignment(SwingConstants.CENTER);
		lblInfo.setFont(new Font("Arial", Font.BOLD, 12));
		lblInfo.setBounds(170, 18, 61, 20);
		panelBottom.add(lblInfo);
		
		// Các nút còn lại
		btnSapXep = new JButton("Sắp Xếp");
		btnSapXep.setBounds(415, 50, 89, 30);
		btnSapXep.addActionListener(this);
		getContentPane().add(btnSapXep);
		
		// them
		btnAdd = new JButton("Thêm");
		btnAdd.setBounds(415, 91, 89, 30);
		btnAdd.addActionListener(this);
		getContentPane().add(btnAdd);
		
		// Huy
		btnCancel = new JButton("Hủy");
		btnCancel.setEnabled(false);
		btnCancel.setBounds(415,132,89,30);
		btnCancel.addActionListener(this);
		getContentPane().add(btnCancel);
		
		// Xoa
		btnDel = new JButton("Xóa");
		btnDel.setBounds(415,173,89,30);
		btnDel.addActionListener(this);
		getContentPane().add(btnDel);
		
		// Thoat
		btnClose = new JButton("Thoát");
		btnClose.setBounds(415, 214, 89, 30);
		btnClose.addActionListener(this);
		getContentPane().add(btnClose);
		
		// Configuration
		setVisible(true);
		setSize(530, 294);
		
		// Mặc định khi hiển thị là item đầu tiên
		showItem(nowPlace); // nowPlace lúc chạy = 0
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// Thực thi nút back
		if (e.getSource() == btnBack) {
			// Kiểm tra giá trị nowPlace nếu == 0 thì ko cho back
			if (nowPlace == 0) {
				JOptionPane.showMessageDialog(this, "Không thể back vì đây là giá trị đầu tiên");
			}
			else {
				// Giảm nowPlace
				nowPlace--;
				
				// Hiển thị
				showItem(nowPlace);
			}
		}
		
		// Thực thi nút Next
		if (e.getSource() == btnNext) {
			// Kiểm tra giá trị nowPlace nếu == giá trị cuối của data thì ko dc next
			if (nowPlace == data.size() - 1) {
				JOptionPane.showMessageDialog(this, "Không thể next vì đây là giá trị cuối");
			}
			else {
				// Tăng nowPlace
				nowPlace++;
				
				// Hiển thị
				showItem(nowPlace);
			}
		}
		
		// Thực thi nút sắp xếp
		if (e.getSource() == btnSapXep) {
			// Lấy lại thông tin mới
			data = qly.sapXepSach();
			
			// Hiển thị giá trị đầu tiên
			nowPlace = 0;
			
			// Hiển thị
			showItem(nowPlace);
		}
		
		// Nút thoát
		if (e.getSource() == btnClose) {
			this.dispose();
		}
		
		// Nút thêm
		if (e.getActionCommand() == "Thêm") {
			// Đổi text nút add và mở nút hủy
			btnAdd.setText("Lưu");
			btnCancel.setEnabled(true);
			
			// Clear hết textBox hiện tại
			txtMaSach.setText("");
			txtNam.setText("");
			txtTenSach.setText("");
		}
		
		// Nút hủy
		if (e.getSource() == btnCancel) {
			// Đổi lại tên nút thêm và tắt nút hủy
			btnAdd.setText("Thêm");
			btnCancel.setEnabled(false);
			
			// Hiện lại giá trị hiện tại
			showItem(nowPlace);
		}
		
		// Nút lưu
		if (e.getActionCommand() == "Lưu") {
			// Kiểm tra nếu nhập đầy đủ
			if (txtMaSach.getText().isEmpty() || txtNam.getText().isEmpty() || txtTenSach.getText().isEmpty()) {
				JOptionPane.showMessageDialog(this, "Xin hãy nhập đầy đủ thông tin!");
			}
			else {
				// Bắt đầu thêm
				try {
					int nam = Integer.parseInt(txtNam.getText());
					
					// Khởi tạo sach
					Sach info = new Sach(txtMaSach.getText(), txtTenSach.getText(), nam);
					
					// Thêm vào kiểm tra
					if (qly.themSach(info)) {
						JOptionPane.showMessageDialog(this, "Thêm thành công!");
						
						// Get lại toàn bộ data và hiển thị giá trị đầu tiên
						nowPlace = 0;
						data = qly.getAllSach();
						showItem(nowPlace);
						
						// Đổi lại tên nút thêm và tắt nút hủy
						btnAdd.setText("Thêm");
						btnCancel.setEnabled(false);
					}
					else {
						JOptionPane.showMessageDialog(this, "Thêm thất bại!");
					}
				}
				catch (NumberFormatException nmr) {
					JOptionPane.showMessageDialog(this, "Năm phải là số!");
				}
			}
		}
		
		// Nút xóa
		if (e.getSource() == btnDel) {
			// Hỏi nếu muốn xóa
			if (JOptionPane.showConfirmDialog(this, "Bạn muốn xóa?") == JOptionPane.YES_OPTION) {
				// Lấy ID sách hiện tại
				String IDHienTai = data.get(nowPlace).getMaSach();
				
				// Bắt đầu xóa và kiểm tra
				if (qly.xoaSach(IDHienTai)) {
					JOptionPane.showMessageDialog(this, "Xóa thành công!");
					
					// Get lại toàn bộ data và hiển thị giá trị đầu tiên
					nowPlace = 0;
					data = qly.getAllSach();
					showItem(nowPlace);
				}
				else {
					JOptionPane.showMessageDialog(this, "Xóa thất bại!");
				}
			}
		}
	}
	
	/*
	 * Show item by place id
	 */
	public void showItem(int id) {
		// Lấy thông tin sách
		Sach info = data.get(id);
		
		// Điền lên textBox
		txtMaSach.setText(info.getMaSach());
		txtNam.setText(Integer.toString(info.getNamXuatBan()));
		txtTenSach.setText(info.getTenSach());
		
		// Sửa lại info
		lblInfo.setText((nowPlace + 1) + "/" + data.size());
	}
}
