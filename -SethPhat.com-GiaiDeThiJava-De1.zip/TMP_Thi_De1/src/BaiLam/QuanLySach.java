package BaiLam;

import java.sql.*;
import java.util.ArrayList;

public class QuanLySach {
	// Thông tin dữ liệu - MySQL
	private String host = "localhost";
	private String data = "db_quanlysach";
	private String user = "root";
	private String pass = "mysql";
	
	// Biến kết nối
	Connection _conn;
	
	// Constructor
	public QuanLySach() {
		try {
			// Kết nối tới SQL
			_conn = DriverManager.getConnection("jdbc:mysql://" + host + "/" + data, user, pass);
		}
		catch (Exception e) {
			
		}
	}
	
	/*
	 * Hàm lấy toàn bộ thông tin
	 * Return: arrayList(Sach)
	 */
	public ArrayList<Sach> getAllSach() {
		// Khởi tạo arrayList
		ArrayList<Sach> data = new ArrayList<Sach>();
		
		try {
			// Tạo statement
			Statement st = _conn.createStatement();
			
			// Query string
			String SQL = "SELECT * FROM sach";
			
			// Execute và lấy dữ liệu
			ResultSet rs = st.executeQuery(SQL);
			
			// Ghi dữ liệu vào arrayList
			while (rs.next()) {
				// Tạo Sach
				Sach info = new Sach();
				
				// Chèn dữ liệu vào
				info.setMaSach(rs.getString("masach"));
				info.setTenSach(rs.getString("tensach"));
				info.setNamXuatBan(rs.getInt("namxuatban"));
				
				// Add vào arrayList
				data.add(info);
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return data;
	}
	
	/*
	 * Hàm sắp xếp sách theo năm tăng dần
	 */
	public ArrayList<Sach> sapXepSach() {
		// Khởi tạo arrayList
		ArrayList<Sach> data = new ArrayList<Sach>();
		
		try {
			// Tạo statement
			Statement st = _conn.createStatement();
			
			// Query string
			String SQL = "SELECT * FROM sach ORDER BY namxuatban";
			
			// Execute và lấy dữ liệu
			ResultSet rs = st.executeQuery(SQL);
			
			// Ghi dữ liệu vào arrayList
			while (rs.next()) {
				// Tạo Sach
				Sach info = new Sach();
				
				// Chèn dữ liệu vào
				info.setMaSach(rs.getString("masach"));
				info.setTenSach(rs.getString("tensach"));
				info.setNamXuatBan(rs.getInt("namxuatban"));
				
				// Add vào arrayList
				data.add(info);
			}
		}
		catch (Exception e) {
			
		}
		
		return data;
	}
	
	/*
	 * Hàm thêm sách vào csdl
	 */
	public boolean themSach(Sach info) {
		
		try {
			// Tạo statement
			Statement st = _conn.createStatement();
			
			// Query string
			String SQL = "INSERT INTO sach VALUES ('"+info.getMaSach()+"','"+info.getTenSach()+"',"+info.getNamXuatBan()+")";
			
			// Execute và kiểm tra
			if (st.executeUpdate(SQL) > 0)
				return true;
			
		}
		catch (Exception e) {
			
		}
		
		return false;
	}
	
	/*
	 * Hàm sửa sách
	 */
	public boolean suaSach(Sach info) {
		
		try {
			// Tạo statement
			Statement st = _conn.createStatement();
			
			// Query string
			String SQL = "UPDATE sach SET tensach = '"+info.getTenSach()+"', namxuatban = "+info.getNamXuatBan()+" WHERE masach = '"+info.getMaSach()+"'";
			
			// Execute và kiểm tra
			if (st.executeUpdate(SQL) > 0)
				return true;
			
		}
		catch (Exception e) {
			
		}
		
		return false;
	}
	
	/*
	 * Hàm xóa sách
	 */
	public boolean xoaSach(String masach) {
		
		try {
			// Tạo statement
			Statement st = _conn.createStatement();
			
			// Query string
			String SQL = "DELETE FROM sach WHERE masach = '"+masach+"'";
			
			// Execute và kiểm tra
			if (st.executeUpdate(SQL) > 0)
				return true;
			
		}
		catch (Exception e) {
			
		}
		
		return false;
	}
}
