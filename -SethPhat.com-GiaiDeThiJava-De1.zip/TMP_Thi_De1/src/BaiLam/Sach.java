package BaiLam;

public class Sach {
	// Member
	private String maSach;
	private String tenSach;
	private int namXuatBan;
	
	/*
	 * Getter/Setter
	 */
	public String getMaSach() {
		return maSach;
	}
	public void setMaSach(String maSach) {
		this.maSach = maSach;
	}
	public String getTenSach() {
		return tenSach;
	}
	public void setTenSach(String tenSach) {
		this.tenSach = tenSach;
	}
	public int getNamXuatBan() {
		return namXuatBan;
	}
	public void setNamXuatBan(int namXuatBan) {
		this.namXuatBan = namXuatBan;
	}
	
	// Constructor with info
	public Sach(String maSach, String tenSach, int namXuatBan) {
		this.maSach = maSach;
		this.tenSach = tenSach;
		this.namXuatBan = namXuatBan;
	}
	
	// Default constructor
	public Sach() {
		
	}
	
	
	
}
